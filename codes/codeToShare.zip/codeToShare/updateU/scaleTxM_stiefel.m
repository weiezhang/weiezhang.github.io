function d = scaleTxM_stiefel(g,h)
d = h*g;