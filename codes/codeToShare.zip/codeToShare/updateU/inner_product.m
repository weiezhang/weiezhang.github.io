function value = inner_product(x,d1,d2)
value = d1(:).'*d2(:);