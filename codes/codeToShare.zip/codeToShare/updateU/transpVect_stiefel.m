function ht = transpVect_stiefel(prob, x, h, d)



